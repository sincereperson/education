//미들웨어
const express =require ('express');
const cors =require('cors');
const path = require('path');
const http = require('http');
const socketIo = require('socket.io');
const app = express();

const server = http.createServer(app);
const io = socketIo(server,{
  cors: {
    origin: "http://localhost:8080", // Vue 앱이 실행되는 주소
    methods: ["GET", "POST"],
    credentials: true // 인증 정보 전송 허용
  }
});



app.use(cors({
  origin : 'http://localhost:8080',
  methods: ['GET', 'POST'],
  credentials : true,
}));

// 'uploads' 폴더를 정적으로 제공
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 상품관련 라우터
const productsRouter = require('./routes/products.js');
app.use(express.json());
app.use(express.urlencoded({ extended : true}));
app.use('/products', productsRouter);

// authenticate 관련 라우터
const authRouter = require('./routes/auth.js');
app.use('/auth', authRouter);

// admin 관련 라우터
const adminRouter  = require('./routes/admin.js');
app.use('/admin',adminRouter);

// creator 관련 라우터
const creatorsRouter  = require('./routes/creators.js');
app.use('/creators', creatorsRouter);

// mypage 관련 라우터
const mypageRouter  = require('./routes/mypage.js');
app.use('/mypage',mypageRouter);

// 채팅방에 참여하는 기능
io.on('connection', (socket) => {
  console.log('New client connected:', socket.id);

  // 방 입장 처리
  socket.on('joinRoom', ({ roomId }) => {
    socket.join(roomId);
    console.log(`User joined room ${roomId}`);
  });

  // 메시지 처리
  socket.on('chatMessage', ({ roomId, message, senderId }) => {
    io.to(roomId).emit('message', { message, senderId });
    console.log(`Message from ${senderId} in room ${roomId}: ${message}`);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

server.listen(3000, () => {
  console.log('서버가 3000번 포트에서 실행 중입니다.');
});

// //실행
// app.listen(3000, function() {
//   console.log('Server Running at http://localhost:3000');
// });

