const express = require('express');
const router = express.Router();
const db = require('../config.js');
const sql = require('../sql.js');
const bcrypt = require('bcrypt');

//회원가입 
router.post('/register', async (req, res) => {
    const { username, email, password, userType } = req.body;
  
    try {
      // 비밀번호 해싱
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
  
      // MySQL 쿼리 작성
      const query = 'INSERT INTO Users (username, email, password, type) VALUES (?, ?, ?, ?)';
  
      // 데이터베이스에 사용자 저장
      db.query(query, [username, email, hashedPassword, userType], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json('Database error');
        }
        res.status(200).json('User registered successfully');
      });
    } catch (err) {
      console.error(err);
      res.status(500).json('Error registering user');
    }
  });
  



// 로그인 API
router.post('/login', (req, res) => {
    const { email, password } = req.body;
  console.log({ email, password });
    // 이메일로 사용자 조회
    const query = 'SELECT * FROM users WHERE email = ?';
    
    
    db.query(query, [email], async (err, results) => {
        console.log(results);
      if (err) {
        console.error('쿼리 실행 중 오류:', err);
        return res.status(500).json({ success: false, message: '서버 오류가 발생했습니다.' });
      }
  
      if (results.length === 0) {
        // 사용자가 없는 경우
        return res.json({ success: false, message: '존재하지 않는 이메일입니다.' });
      }
  
      const user = results[0];
  
      // 비밀번호 확인
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.json({ success: false, message: '비밀번호가 일치하지 않습니다.' });
      }
  
      // 로그인 성공
      res.json({
        success: true,
        member: {
          id: user.id,       // 유저 ID
          email: user.email, // 유저 이메일
          type: user.type,   // 유저 타입 (admin, seller, buyer 등)
        },
      });
    });
}),
    
//카카오 회원가입
router.post('/kakaoJoin'), function(req, res) {
    const kakao = req.body;
    const kakaoJoin = `INSERT INTO Users (username, email, user_type) VALUES(?,?,?)`;
    const kakao_check = `SELECT * FROM member WHERE member_email = ?`;

    //데이터 없을 시 가입
    db.query(kakao_check, [kakao.email], function(error, results, fields) {
        if(results.length <= 0) {
            db.query(kakaoJoin, [username, email ], function(error, result) {
                if(error) {
                    console.error(error);
                    return response.status(500).json({error: 'error'});
                }else {
                    return response.status(200).json({
                        message: '저장완료'
                    })
                }
            })
        }else {
            return response.status(200).json({
                message: 'already_exist_id'
            })
        }
    })
}


// 카카오 로그인
router.post('/kakaoLoginProcess', function (request, response) {
    const kakao = request.body;
    const kakao_check = `SELECT * FROM Users WHERE email = ?`;
    const kakaoJoin = `INSERT INTO Users (username, email) VALUES(?,?)`;
    const getUsersId = `SELECT id FROM Users`
    // 데이터 없을 시 회원가입도 진행
    db.query(kakao_check, [kakao.email], function (error, results, fields) {
        if (results.length <= 0) {
            db.query(kakaoJoin, [kakao.username, kakao.email], function (error, result) {
                if (error) {
                    console.error(error);
                    return response.status(500).json({ error: 'error' });
                }
            })
        }
        // 로그인 
        db.query(getUsersId, [kakao.email], function (error, results, fields) {

            if (error) {
                console.log(error)
            }
            return response.status(200).json({
                message: results[0].member_number
            })
        })
    })
})



// 관리자 체크 
router.post('/admin_check', function (request, response) {
    const loginUser = request.body;

    db.query(sql.admin_check, [loginUser.member_number], function (error, results, fields) {
        if (results[0].MEMBER_TYPE == 1) {
            // 로그인한 유저의 TP가 1(관리자)인 경우    
            return response.status(200).json({
                message: 'admin'
            })
        }
        else if (results[0].MEMBER_TYPE == 0) {
            return response.status(200).json({
                message: 'member'
            })
        } else {
            console.error(error);
        }
    })
});

module.exports = router;