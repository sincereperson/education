const express = require('express');
const router = express.Router();
const db = require('../config.js'); // 데이터베이스 연결

// 크리에이터 목록 가져오기 (seller 타입만)
router.get('/listUp', (req, res) => {
  const query = "SELECT * FROM users WHERE type = 'seller'"; // seller 타입만 가져옴

  db.query(query, (err, result) => {
    // console.log(result);
    if (err) {
      console.error('데이터베이스 오류:', err);
      return res.status(500).json({ error: '데이터베이스 오류 발생' });
    }

    if (result.length === 0) {
      return res.status(404).json({ message: '크리에이터를 찾을 수 없습니다.' });
    }

    res.status(200).json(result); // 크리에이터 목록을 반환
  });
});

// 특정 크리에이터의 프로필 및 등록한 작품 가져오기
router.get('/profile/:id', (req, res) => {
    const creatorId = req.params.id;

    // 크리에이터 정보 가져오기
    const userQuery = 'SELECT * FROM users WHERE id = ?';
    // 해당 크리에이터의 작품 목록 가져오기
    const productsQuery = 'SELECT * FROM products WHERE user_id = ?';

    db.query(userQuery, [creatorId], (err, userResult) => {
        if (err) {
            return res.status(500).json({ error: '데이터베이스 오류 발생' });
        }

        if (userResult.length === 0) {
            return res.status(404).json({ message: '크리에이터를 찾을 수 없습니다.' });
        }

        const userProfile = userResult[0]; // 크리에이터 프로필 정보
        console.log(userProfile); // 이제 userProfile이 선언된 후 로그를 찍음

        // 등록한 작품 목록 가져오기
        db.query(productsQuery, [creatorId], (err, productsResult) => {
            if (err) {
                return res.status(500).json({ error: '데이터베이스 오류 발생' });
            }

            res.status(200).json({
                userProfile,    // 크리에이터 프로필 정보
                products: productsResult // 크리에이터가 등록한 작품 목록
            });
        });
    });
});
  

module.exports = router;
