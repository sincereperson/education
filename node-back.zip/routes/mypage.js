const express = require('express');
const multer = require('multer');
const path = require('path');
const db = require('../config.js');
const router = express.Router();

// 파일 업로드를 위한 Multer 설정
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname)); // 파일명 중복 방지
  }
});

const upload = multer({ storage: storage });

// 프로필 정보를 가져오는 라우트
router.get('/profile/:id', (req, res) => {
    const userId = req.params.id;  // 전달받은 유저 ID 사용
    // console.log(userId);
  
    const query = 'SELECT username, email, self_intro, profile_image, balance, type FROM users WHERE id = ?';
  
    db.query(query, [userId], (err, result) => {
      if (err) {
        console.error('프로필 정보를 가져오는 중 오류 발생:', err);
        return res.status(500).json({ error: '프로필 정보를 가져오는 중 오류가 발생했습니다.' });
      }
  
      if (result.length === 0) {
        return res.status(404).json({ message: '사용자를 찾을 수 없습니다.' });
      }
      console.log(result);
      const userProfile = result[0]; // 프로필 정보
      res.status(200).json(userProfile); // 프로필 정보를 클라이언트로 반환
    });
  });

// 프로필 업데이트 라우트
router.post('/update-profile/:id', upload.single('profile_image'), (req, res) => {
//   console.log(req.body);
  const { self_intro } = req.body;
  const profileImage = req.file ? req.file.filename : null;

  const userId = req.params.id; // 로그인된 사용자의 ID

  let query = 'UPDATE users SET self_intro = ?';
  let queryParams = [self_intro, userId];

  if (profileImage) {
    query += ', profile_image = ?';
    queryParams = [self_intro, profileImage, userId];
  }

  query += ' WHERE id = ?';

  db.query(query, queryParams, (err, result) => {
    if (err) {
      console.error('프로필 업데이트 중 오류 발생:', err);
      return res.status(500).json({ error: '프로필 업데이트 중 오류 발생' });
    }

    res.status(200).json({ message: '프로필이 성공적으로 업데이트되었습니다.' });
  });
});


// 구매 내역 조회 API
router.get('/purchases/:userId', (req, res) => {
  const userId = req.params.userId;
  const query = `
    SELECT t.*, p.title, p.price 
    FROM transactions t
    JOIN products p ON t.product_id = p.id
    WHERE t.buyer_id = ? AND t.status = 'completed';
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: '구매 내역 조회 중 오류가 발생했습니다.', error: err });
    }
    res.status(200).json(results);
  });
});

// 판매 내역 조회 API
router.get('/sales/:userId', (req, res) => {
  const userId = req.params.userId;
  const query = `
    SELECT t.*, p.title, p.price 
    FROM transactions t
    JOIN products p ON t.product_id = p.id
    WHERE t.seller_id = ? AND t.status = 'completed';
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      return res.status(500).json({ success: false, message: '판매 내역 조회 중 오류가 발생했습니다.', error: err });
    }
    res.status(200).json(results);
  });
});




//1대1문의 라우트
router.get('/inquiries/:id', (req, res) => {
    const userId = req.params.id;
  
    const query = 'SELECT * FROM inquiries WHERE user_id = ?';
  
    db.query(query, [userId], (err, result) => {
      if (err) {
        console.error('1대1 문의 정보를 가져오는 중 오류 발생:', err);
        return res.status(500).json({ error: '데이터베이스 오류 발생' });
      }
  
      res.status(200).json(result); // 1대1 문의 정보를 반환
    });
  });

  router.post('/inquiries/create', (req, res) => {
    const { user_id, title, content } = req.body;
  
    const query = 'INSERT INTO inquiries (user_id, title, content, status) VALUES (?, ?, ?, "pending")';
  
    db.query(query, [user_id, title, content], (err, result) => {
      if (err) {
        console.error('1대1 문의 등록 중 오류 발생:', err);
        return res.status(500).json({ error: '데이터베이스 오류 발생' });
      }
  
      res.status(200).json({ success: true, message: '문의가 성공적으로 등록되었습니다.' });
    });
  });



module.exports = router;
