const express = require('express');
const multer = require('multer');
const path = require('path');
const router = express.Router();
const { v4: uuidv4 } = require('uuid'); // UUID를 사용하여 고유한 파일명 생성
const db = require('../config.js'); // 데이터베이스 연결 파일

// Multer 설정 (파일 저장 경로 및 파일명 설정)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // 파일이 저장될 경로
  },
  filename: (req, file, cb) => {
    // UUID + 현재 시간을 파일명으로 설정하여 고유한 파일명을 생성
    const uniqueSuffix = `${uuidv4()}-${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueSuffix); // 고유 파일명 설정
  }
});

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 파일 크기 제한: 5MB
});

// 상품 등록 라우트 (필드 이름 'images'에 맞춰 설정)
router.post('/register', upload.array('images', 10), (req, res) => {
  // console.log(req.body);
  const { title, description, price, tags, userEmail } = req.body;

  // tags를 배열 형태로 받는다고 가정하고 JSON 문자열로 변환
  const tagsArray = JSON.parse(tags);

  const images = req.files.map((file) => file.filename); // 업로드된 파일명들 배열로 저장
  console.log('업로드된 이미지 파일명들:', images); // 콘솔로 이미지 확인

  try {
    const query = 'INSERT INTO products (title, description, price, images, tags, user_id) VALUES (?, ?, ?, ?, ?, ?)';
    const imagesString = images.join(','); // 이미지 파일명 배열을 쉼표로 구분된 문자열로 변환
    const tagsString = JSON.stringify(tagsArray); // tags 배열을 문자열로 변환

    db.query(query, [title, description, price, imagesString, tagsString, userEmail], (err, result) => {
      if (err) {
        console.error('상품 등록 중 오류:', err);
        return res.status(500).json({ success: false, message: '상품 등록 실패', error: err.message });
      }

      res.status(200).json({ success: true, message: '상품 등록 성공!', images });
    });
  } catch (error) {
    console.error('상품 등록 중 오류:', error);
    res.status(500).json({ success: false, message: '상품 등록 실패', error: error.message });
  }
});

// 상품 목록 API (페이징 지원)
router.get('/products', (req, res) => {
  const page = parseInt(req.query.page) || 1; // 현재 페이지 (기본값 1)
  const itemsPerPage = parseInt(req.query.limit) || 6; // 한 페이지에 표시할 상품 수 (기본값 4)
  const offset = (page - 1) * itemsPerPage; // 시작 지점 계산

  // 전체 상품 수를 가져옴
  const countQuery = 'SELECT COUNT(*) AS total FROM products';
  db.query(countQuery, (err, countResult) => {
    if (err) return res.status(500).json({ error: '데이터베이스 오류' });

    const totalItems = countResult[0].total; // 전체 상품 수
    const totalPages = Math.ceil(totalItems / itemsPerPage); // 전체 페이지 수 계산

    // 페이지에 맞는 상품 목록 가져오기
    const query = 'SELECT * FROM products WHERE status = "available" LIMIT ? OFFSET ?';
    db.query(query, [itemsPerPage, offset], (err, results) => {
      if (err) return res.status(500).json({ error: '데이터베이스 오류' });
      // console.log(results);

      res.json({
        products: results,
        totalPages,
        currentPage: page
      });
    });
  });
});

// 상품 상세 정보 API
router.get('/:id', (req, res) => {
  // 클라이언트로부터 전달된 상품 ID를 파라미터로 받음
  const productId = parseInt(req.params.id);

  // 상품 ID가 정수로 변환되지 않으면 오류 처리
  if (isNaN(productId)) {
    return res.status(400).json({ error: '잘못된 상품 ID입니다.' });
  }

  // 상품 정보를 조회하는 쿼리
  const query = 'SELECT * FROM products WHERE id = ?';

  // 데이터베이스에서 상품 조회
  db.query(query, [productId], (err, result) => {
    if (err) {
      console.error('데이터베이스 오류 발생:', err);
      return res.status(500).json({ error: '데이터베이스 오류가 발생했습니다.' });
    }

    // 상품이 존재하지 않으면 404 응답 반환
    if (result.length === 0) {
      return res.status(404).json({ error: '상품을 찾을 수 없습니다.' });
    }

    // 조회된 상품 데이터를 클라이언트로 반환
    res.status(200).json(result[0]);
  });
});



router.post('/purchase', (req, res) => {
  const { productId, buyerId } = req.body;

  const productQuery = 'SELECT price, user_id AS seller_id FROM products WHERE id = ?';
  db.query(productQuery, [productId], (err, productResult) => {
    if (err) {
      return res.status(500).json({ success: false, message: '데이터베이스 오류' });
    }

    if (productResult.length === 0) {
      return res.status(404).json({ success: false, message: '상품을 찾을 수 없습니다.' });
    }

    const productPrice = productResult[0].price;
    const sellerId = productResult[0].seller_id;

    const userQuery = 'SELECT balance FROM users WHERE id = ?';
    db.query(userQuery, [buyerId], (err, userResult) => {
      if (err) {
        return res.status(500).json({ success: false, message: '데이터베이스 오류' });
      }

      const buyerBalance = userResult[0].balance;

      if (buyerBalance < productPrice) {
        return res.status(400).json({ success: false, message: '잔액이 부족합니다.' });
      }

      db.getConnection((err, connection) => {
        if (err) {
          return res.status(500).json({ success: false, message: '트랜잭션 연결 오류' });
        }

        connection.beginTransaction((err) => {
          if (err) {
            return res.status(500).json({ success: false, message: '트랜잭션 오류' });
          }

          const transactionQuery = `
            INSERT INTO transactions (buyer_id, seller_id, product_id, amount, status)
            VALUES (?, ?, ?, ?, 'pending')
          `;
          connection.query(transactionQuery, [buyerId, sellerId, productId, productPrice], (err, transactionResult) => {
            if (err) {
              return connection.rollback(() => {
                res.status(500).json({ success: false, message: '구매 처리 중 오류가 발생했습니다.' });
              });
            }

            const buyerUpdateQuery = 'UPDATE users SET balance = balance - ? WHERE id = ?';
            connection.query(buyerUpdateQuery, [productPrice, buyerId], (err) => {
              if (err) {
                return connection.rollback(() => {
                  res.status(500).json({ success: false, message: '구매자 잔액 업데이트 중 오류가 발생했습니다.' });
                });
              }

              const completeTransactionQuery = 'UPDATE transactions SET status = ? WHERE id = ?';
              connection.query(completeTransactionQuery, ['completed', transactionResult.insertId], (err) => {
                if (err) {
                  return connection.rollback(() => {
                    res.status(500).json({ success: false, message: '거래 완료 처리 중 오류가 발생했습니다.' });
                  });
                }

                const sellerUpdateQuery = 'UPDATE users SET balance = balance + ? WHERE id = ?';
                connection.query(sellerUpdateQuery, [productPrice, sellerId], (err) => {
                  if (err) {
                    return connection.rollback(() => {
                      res.status(500).json({ success: false, message: '판매자 잔액 업데이트 중 오류가 발생했습니다.' });
                    });
                  }

                  // 작품 상태를 'sold'로 업데이트
                  const updateProductStatusQuery = 'UPDATE products SET status = ? WHERE id = ?';
                  connection.query(updateProductStatusQuery, ['sold', productId], (err) => {
                    if (err) {
                      return connection.rollback(() => {
                        res.status(500).json({ success: false, message: '상품 상태 업데이트 중 오류가 발생했습니다.' });
                      });
                    }

                    connection.commit((err) => {
                      if (err) {
                        return connection.rollback(() => {
                          res.status(500).json({ success: false, message: '트랜잭션 커밋 중 오류가 발생했습니다.' });
                        });
                      }

                      res.status(200).json({ success: true, message: '구매가 완료되었습니다!' });
                    });
                  });
                });
              });
            });
          });
        });
      });
    });
  });
});




// 환급 신청 내역 조회 라우트
router.get('/withdrawals/:userId', (req, res) => {
  const userId = req.params.userId;

  const query = `
    SELECT w.id AS withdrawal_id, w.amount, w.status, w.created_at
    FROM withdrawals w
    WHERE w.user_id = ?;
  `;

  db.query(query, [userId], (err, results) => {
    if (err) {
      console.error('환급 신청 내역 조회 중 오류:', err);
      return res.status(500).json({ error: '환급 신청 내역 조회 중 오류가 발생했습니다.' });
    }

    res.status(200).json({ withdrawals: results });
  });
});

// 환급 신청 라우트
router.post('/withdrawals/create', (req, res) => {
  const { userId, amount } = req.body;

  const query = `
    INSERT INTO withdrawals (user_id, amount, status, created_at)
    VALUES (?, ?, 'pending', NOW());
  `;

  db.query(query, [userId, amount], (err, result) => {
    if (err) {
      console.error('환급 신청 처리 중 오류:', err);
      return res.status(500).json({ error: '환급 신청 처리 중 오류가 발생했습니다.' });
    }

    res.status(200).json({ success: true, message: '환급 신청이 성공적으로 처리되었습니다.' });
  });
});

module.exports = router;
