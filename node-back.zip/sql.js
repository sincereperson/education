// 쿼리문 작성하고 변수에 저장하는 곳
module.exports = {
    //상품 관련 쿼리문
    goodsInsert: `INSERT INTO goods (goods_name,goods_price,goods_degree,goods_kind) values (?,?,?,?)`,

    // auth
    id_check: `SELECT * FROM member WHERE member_email = ? and member_block = 0`,
    get_member_number: `SELECT member_number FROM member WHERE member_pw = ?`,
    login: `SELECT member_pw FROM member WHERE member_email = ?`,

    //카카오 로그인
    kakaoJoin: `INSERT INTO member (member_email, member_nickname) VALUES(?,?)`,
    kakao_check: `SELECT * FROM member WHERE member_email = ?`,

    //아이디 비번 찾기
    id_find: `SELECT member_email FROM member WHERE member_phone = ?`,
    member_check: `SELECT member_number FROM member WHERE member_phone = ? AND member_email = ?`,
    pass_update_tem: `UPDATE member SET member_pw = ? WHERE member_email = ?`,

    //회원가입
    join: `insert into member( member_nickname, member_jumin, member_email, member_pw,
           member_phone, member_zipcode, member_address1, member_address2) values(?,?,?,?,?,?,?,?)`,

    // admin 기능 
    admin_check: `SELECT MEMBER_TYPE FROM MEMBER WHERE MEMBER_NUMBER = ?`,
}
