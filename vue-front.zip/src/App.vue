<template>
  <div>
    <router-view/>
  </div>
</template>

<script>
  export default {
    path : '/',
    redirect: '/main'
  }
</script>