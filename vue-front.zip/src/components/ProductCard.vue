<template>
  <div class="product-card">
    <img :src="product.image" alt="Product Image" />
    <h3>{{ product.title }}</h3>
    <p>{{ product.price }}원</p>
  </div>
</template>

<script>
export default {
  props: ['product'],
};
</script>

<style scoped>
.product-card {
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.2s;
}

.product-card img {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.product-card h3 {
  margin: 10px;
  font-size: 1.2rem;
}

.product-card p {
  margin: 10px;
  color: #888;
}

.product-card:hover {
  transform: scale(1.05);
}
</style>