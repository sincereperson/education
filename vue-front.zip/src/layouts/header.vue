<template>
  <header class="p-6">
    <div class="container">
      <div class="d-flex flex-wrap justify-content-lg">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none mt-2">
          <img src="../assets/logo.png" class="bi" width="300" height="90" @click="goToMain()">
        </a>

        <div class="d-flex col-2"></div>

        <div class="col-4">
          <!-- <form class="mt-5">
            <input class="form-control-sm me-2" placeholder="제품 명 검색" @keyup.enter="goToSearch(keyword)" v-model="keyword">
            <button class="btn btn-outline-*" @click="goToSearch(keyword)"><i class="fa-solid fa-magnifying-glass fa-lg"></i></button>
          </form> -->
        </div>

        <!-- 로그인 상태 확인 -->
        <div v-if="member.email === ''" class="text-end pull-right mt-5 mx-auto">
          <button type="button" @click="goToLogin()" class="btn btn-outline-*">로그인</button>
          <span>/</span>
          <button type="button" @click="JoinSelect()" class="btn btn-outline-*">회원가입</button>
        </div>

        <div v-else-if="admin_check == 1" class="text-end pull-right mt-5 mx-auto">
          <div class="pt-4">
            <button type="button" @click="logout()" class="btn btn-outline-*">로그아웃</button>
            <button type="button" @click="goToAdmin()" class="btn btn-outline-*"><i class="fa-solid fa-user-shield"></i> 관리자</button>
          </div>
        </div>

        <div v-else class="text-end pull-right mt-5 mx-auto">
          <div class="pt-4">
            <button type="button" @click="logout()" class="btn btn-outline-*">로그아웃</button>
            <!-- <button type="button" @click="goToBasket()" class="btn btn-outline-*"><i class="fa-solid fa-bag-shopping fa-xl"></i></button> -->
            <button type="button" @click="goToMypage()" class="btn btn-outline-*"><i class="fa-solid fa-user-large fa-xl"></i></button>
          </div>
        </div>
      </div>

      <nav class="nav nav-underline nav-justified mt-4" style="font-size: large;">
        <a class="nav-link active" @click="goToMain()">HOME</a>
        <a class="nav-link active" @click="goToCreator()">CREATOR</a>
        <a class="nav-link active" @click="goToPicture()">작품 마당</a>
      </nav>
    </div>
  </header>
</template>

<script>
// import axios from 'axios';

export default {
  data() {
    return {
      admin_check: null, // 관리자 여부
      keyword: '', // 검색어
    };
  },
  computed: {
    member() {
      return this.$store.state.member; // Vuex 상태에서 회원 정보 가져오기
    },
  },
  created() {
    this.adminCheck(); // 관리자 여부 확인
  },
  methods: {
    goToSearch(keyword) {
      if (keyword === '') {
        alert('검색어를 입력하세요');
      } else {
        this.$router.push({ path: `/goods_search/${keyword}` });
      }
    },
    goToLogin() {
      this.$router.push({ path: '/login' });
    },
    goToMain() {
      this.$router.push({ path: '/' });
    },
    goToCreator() {
      this.$router.push({ path: '/creatorList' });
    },
    goToText() {
      this.$router.push({ path: '/text_list' });
    },
    goToPicture() {
      this.$router.push({ path: '/productsList' });
    },
    JoinSelect() {
      this.$router.push({ path: '/join_select' });
    },
    goToMypage() {
      this.$router.push({ path: '/mypage' });
    },
    async  logout() {
    this.$store.dispatch('resetStore'); // 로그아웃 시 상태 초기화
    this.$router.push('/login'); // 로그인 페이지로 이동
  },
    goToAdmin() {
      this.$router.push({ path: '/admin/admin_news' });
    },
    adminCheck() {
      if (this.member.email === '') {
        console.log('로그인 상태가 아닙니다.');
      } else if (this.member.type === 'admin') {
        this.admin_check = 1;  // 관리자 여부 확인
      } else {
        this.admin_check = 0;  // 일반 사용자
      }
    },
  },
};

</script>

<style>
header {
  background-color: white;
}

.nav-underline .nav-link.active {
  color: black;
  background-color: white;
  border-bottom-color: gray;
}

.nav-underline .nav-link {
  color: gray;
  border-bottom: 2px solid #007bff;
}

.nav-underline .nav-link:hover {
  color: #007bff;
  border-bottom-color: #007bff;
}

.mb-4 {
  margin-bottom: 2.5rem;
}

.mb-5 {
  margin-bottom: 2.9rem;
}
</style>
