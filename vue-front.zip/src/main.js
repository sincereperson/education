import { createApp } from 'vue'
import App from './App.vue'
import store from './store'
import { createRouter,createWebHistory } from 'vue-router'

//layout
import layout_form from './layouts/layout_form.vue'
import main from './views/main.vue'


//auth
import join from './views/auth/join.vue'
import login from './views/auth/login.vue'
import join_select from './views/auth/join_select.vue'

//creator
import creatorList from './views/creator/creatorList'
import creatorProfile from './views/creator/creatorProfile.vue'

//goods
// main.js 또는 사용하는 컴포넌트에 추가
import 'swiper/swiper-bundle.css';
import goods_add_picture from './views/goods/goods_add_picture'
import productsDetail from './views/goods/productsDetail'
import productsList from './views/goods/productsList.vue'

//mypage
import mypage from './views/mypage/mypage.vue'



const routes = [
  {
    path : '/',
    redirect : 'main',
    name : layout_form,
    component : layout_form,
    children : [
      {
        path : '/main',
        name : main,
        component : main,
      },
      {
        path : '/login',
        name : login,
        component : login,
      },
      {
        path : '/join',
        name : join,
        component : join,
      },
      {
        path : '/join_select',
        name : join_select,
        component : join_select,
      },
      {
        path : '/creatorList',
        name : creatorList,
        component : creatorList,
      },
      {
        path: '/creators/:id', 
        name: 'creatorProfile',
        component: creatorProfile,
      },
      {
        path : '/mypage',
        name : mypage,
        component : mypage,
      },
      {
        path : '/goods_add_picture',
        name : goods_add_picture,
        component : goods_add_picture,
      },
      {
        path : '/productsList',
        name : productsList,
        component : productsList,
      },
      {
        path : '/productsDetail/:id',
        name : productsDetail,
        component : productsDetail,
      },

    ]
  }
]




const router = createRouter({
  history : createWebHistory(),
  routes,
  scrollBehavior(){
    return { top: 0 }
  },
});




const app = createApp(App)
app.use(router);
app.use(store);
app.mount('#app')

// 카카오 디벨로퍼 api키
window.Kakao.init('169468a12a13344d69385907f64d2d41');