import { createStore } from 'vuex';
import createPersistedState from 'vuex-persistedstate'; // 상태 유지 플러그인

// 초기 상태를 반환하는 함수
const getDefaultState = () => ({
  member: {
    id: '',
    email: '',
    type: '',
  }
});

const store = createStore({
  state: getDefaultState(),
  mutations: {
    // Vuex 상태에서 member 데이터 업데이트
    setMember(state, memberData) {
      state.member = { ...state.member, ...memberData }; // 기존 상태에 업데이트
    },

    // 상태 초기화: 로그아웃 시 전체 상태를 초기화
    resetState(state) {
      Object.assign(state, getDefaultState()); // 전체 상태 초기화
    },
  },
  actions: {
    // 상태 초기화 액션: 필요 시 호출
    resetStore({ commit }) {
      commit('resetState'); // 상태 전체 초기화
    },
  },
  plugins: [
    createPersistedState({
      paths: ['member'], // member 상태만 로컬 스토리지에 저장
    }),
  ],
});

export default store;
