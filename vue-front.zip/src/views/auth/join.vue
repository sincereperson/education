<template>
  <div class="signup-container">
    <div class="signup-box">
      <h2>Sign Up</h2>
      <form @submit.prevent="register">
        <div class="input-group">
          <label for="username">닉네임</label>
          <input type="text" id="username" v-model="username" placeholder="이름을 입력해주세요" required />
        </div>

        <div class="input-group">
          <label for="email">Email</label>
          <input type="email" id="email" v-model="email" placeholder="Email을 입력해주세요" required />
        </div>

        <div class="input-group">
          <label for="password">Password</label>
          <input type="password" id="password" v-model="password" placeholder="비밀번호를 입력해주세요" required />
        </div>

        <div class="input-group">
          <label for="userType">회원 타입</label>
          <select v-model="userType" required>
            <option value="buyer">구매자</option>
            <option value="seller">창작자</option>
          </select>
        </div>

        <button type="submit" class="signup-btn">회원가입 완료</button>
      </form>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      username: '',
      email: '',
      password: '',
      userType: 'buyer', // 기본값
    };
  },
  methods: {
    async register() {
      try {
          await axios.post('http://localhost:3000/auth/register', {
          username: this.username,
          email: this.email,
          password: this.password,
          userType: this.userType,
        });
        alert('Registration successful!');
      } catch (error) {
        console.error(error);
        alert('Registration failed.');
      }
    },
  },
};
</script>

<style scoped>
.signup-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f0f0f0;
}

.signup-box {
  background-color: white;
  padding: 2rem;
  border-radius: 10px;
  box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
  width: 400px;
  text-align: center;
}

h2 {
  font-size: 2rem;
  margin-bottom: 2rem;
  color: #333;
}

.input-group {
  margin-bottom: 1.5rem;
  text-align: left;
}

.input-group label {
  display: block;
  margin-bottom: 0.5rem;
  font-size: 1rem;
  color: #666;
}

.input-group input,
.input-group select {
  width: 100%;
  padding: 0.75rem;
  border: 1px solid #ddd;
  border-radius: 5px;
  font-size: 1rem;
}

.input-group input:focus,
.input-group select:focus {
  outline: none;
  border-color: #007bff;
}

.signup-btn {
  width: 100%;
  padding: 0.75rem;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1rem;
  transition: background-color 0.3s;
}

.signup-btn:hover {
  background-color: #0056b3;
}
</style>
