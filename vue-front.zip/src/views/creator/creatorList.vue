<template>
  <div class="container my-5">
    <h2 class="text-center mb-4">크리에이터 목록</h2>
    <div class="row">
      <div v-for="(creator, index) in creators" :key="index" class="col-lg-3 col-md-4 col-sm-6 mb-4">
        <div class="card h-100">
          <img :src="getImageUrl(creator.profile_image)" class="card-img-top pt-3" alt="크리에이터 이미지">
          <div class="card-body">
            <h5 class="card-title">{{ creator.username }}</h5>
            <p class="card-text">{{ creator.self_intro || '소개 정보가 없습니다.' }}</p>
            <a :href="`/creators/${creator.id}`" class="btn btn-primary">프로필 보기</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      creators: [] // 크리에이터 목록
    };
  },
  created() {
    this.fetchCreators();
  },
  methods: {
    // 크리에이터 목록 가져오기
    async fetchCreators() {
      try {
        const response = await axios.get('http://localhost:3000/creators/listUp');
        this.creators = response.data; // 서버에서 받은 크리에이터 데이터를 설정
        console.log(this.creators);
      } catch (error) {
        console.error('크리에이터 목록을 가져오는 중 오류가 발생했습니다:', error);
      }
    },
    // 프로필 이미지 URL 설정
    getImageUrl(profileImage) {
      return profileImage ? `http://localhost:3000/uploads/${profileImage}` : 'http://localhost:3000/uploads/default_profile.png';
    }
  }
};
</script>

<style>
/* 카드 이미지 스타일 */
.card-img-top {
  height: 200px;
  object-fit: contain; /* 이미지 비율을 유지하면서 박스에 맞춤 */
}

/* 카드 레이아웃을 균형 있게 배치 */
.card {
  transition: transform 0.2s;
}

.card:hover {
  transform: translateY(-10px);
}

.text-center {
  text-align: center;
}

h2 {
  color: #333;
}

</style>
