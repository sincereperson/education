<template>
    <div class="container mt-5">
      <div class="row">
        <!-- 크리에이터 프로필 섹션 -->
        <div class="col-lg-4 col-md-5 mb-4 mt-5 h-50">
          <div class="card h-50">
            <img :src="getImageUrl(userProfile.profile_image)" class="card-img-top bal" alt="프로필 이미지">
            <div class="card-body">
              <h5 class="card-title">{{ userProfile.name }}</h5>
              <p class="card-text">이메일: {{ userProfile.email }}</p>
              <p class="card-text">소개: {{ userProfile.bio || '소개 정보가 없습니다.' }}</p>
            </div>
          </div>
        </div>
  
        <!-- 등록한 작품 섹션 -->
        <div class="col-lg-8 col-md-7">
          <h4>등록한 작품</h4>
          <div class="row">
            <div v-for="(product, index) in products" :key="index" class="col-lg-4 col-md-6 mb-4">
              <div class="card h-100">
                <img :src="getProductImage(product.images)" class="card-img-top bal" alt="작품 이미지">
                <div class="card-body">
                  <h5 class="card-title">{{ product.title }}</h5>
                  <p class="card-text">{{ product.description || '설명 없음' }}</p>
                  <p class="card-text"><strong>{{ product.price }}원</strong></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
  data() {
    return {
      userProfile: {}, // 프로필 초기화
      products: []     // 등록한 작품 초기화
    };
  },
  computed: {
  member() {
    return this.$store.state.member; // Vuex의 member 상태 직접 참조
  }
},
  created() {
    this.fetchCreatorProfile();
  },
  methods: {
    async fetchCreatorProfile() {
      const creatorId = this.$route.params.id; // URL에서 크리에이터 ID 가져오기
      try {
        const response = await axios.get(`http://localhost:3000/creators/profile/${creatorId}`);
        this.userProfile = response.data.userProfile;
        this.products = response.data.products;
      } catch (error) {
        console.error('크리에이터 정보를 가져오는 중 오류가 발생했습니다:', error);
      }
    },
    getImageUrl(profileImage) {
      return profileImage ? `http://localhost:3000/uploads/${profileImage}` : 'http://localhost:3000/uploads//default_profile.png';
    },
    getProductImage(images) {
      const firstImage = images.split(',')[0]; // 첫 번째 이미지를 사용
      return `http://localhost:3000/uploads/${firstImage}`;
    }
  }
};
  </script>
  
  <style scoped>
  .bal{
    object-fit: contain; /* 이미지 비율을 유지하면서 박스에 맞춤 */
  }
  .card-img-top {
    height: 200px;
    object-fit: contain; /* 이미지 비율을 유지하면서 박스에 맞춤 */
  }
  
  .card {
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    transition: transform 0.3s ease;
  }
  
  .card:hover {
    transform: scale(1.05);
  }
  
  h4 {
    margin-bottom: 20px;
  }
  
  .container {
    margin-top: 20px;
  }
  
  </style>
  