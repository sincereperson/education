<template>
  <div v-if="member.type === 'seller' || member.type ==='admin'" class="upload-page">
    <h2>작품 등록</h2>
    <form @submit.prevent="submitProduct" class="upload-form mt-10">

      <!-- 상품 제목 입력 -->
      <div class="input-group">
        <label for="title" class="form-label">상품 제목</label>
        <input type="text" v-model="title" placeholder="상품 제목을 입력하세요" v-on:keydown.enter.prevent required class="form-input" />
      </div>

      <!-- 상품 설명 입력 -->
      <div class="input-group">
        <label for="description" class="form-label">상품 설명</label>
        <textarea v-model="description" placeholder="상품 설명을 입력하세요" class="form-textarea"></textarea>
      </div>

      <!-- 가격 입력 -->
      <div class="input-group">
        <label for="price" class="form-label">가격</label>
        <input type="number" v-model="price" placeholder="가격을 입력하세요" v-on:keydown.enter.prevent required class="form-input" />
      </div>

      <!-- 태그 입력 -->             
      <div class="input-group">
        <label for="tags" class="form-label">카테고리 태그</label>
        <input
          type="text"
          id="tags"
          v-model="newTag"
          v-on:keydown.enter.prevent='addTag'
          placeholder="태그 입력 후 Enter"
          class="form-input"
        />
        <div class="tags-container">
          <span v-for="(tag, index) in tags" :key="index" class="tag">
            {{ tag }} <button type="button" @click="removeTag(index)" class="remove-tag">x</button>
          </span>
        </div>
      </div>
      <!-- 이미지 파일 선택 -->
      <div class="input-group">
        <label for="images" class="form-label">이미지 파일 업로드</label>
        <input type="file" id="images" ref="images" multiple @change="handleFiles" class="form-input" />
        <div v-if="imagePreviews.length" class="image-preview-container">
          <img v-for="(image, index) in imagePreviews" :src="image" :key="index" class="preview-image" />
        </div>
      </div>

      <button type="submit" class="submit-btn" >상품 등록</button>
    </form>
  </div>

  <div v-else class="text-center pull-right mt-5 mx-auto">
    <h6>
    이 페이지는 창작자만 이용할 수 있습니다.
    </h6>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      title: '',
      description: '',
      price: '',
      newTag: '',
      tags: [],
      imagePreviews: [],
      files: []
    };
  },
 computed: {
  member() {
    return this.$store.state.member; // Vuex의 member 상태 직접 참조
  }
},
  methods: {
    handleFiles(event) {
      const selectedFiles = Array.from(event.target.files);
      this.files = selectedFiles;
      this.imagePreviews = [];

      selectedFiles.forEach(file => {
        const reader = new FileReader();
        reader.onload = (e) => {
          this.imagePreviews.push(e.target.result);
        };
        reader.readAsDataURL(file);
      });
    },
    addTag() {
      console.log(this.member.id)
      if (this.newTag !== '' && !this.tags.includes(this.newTag)) {
        this.tags.push(this.newTag);
        this.newTag = '';
      }
    },
    removeTag(index) {
      this.tags.splice(index, 1);
    },
    async submitProduct() {
      
      const formData = new FormData();
      formData.append('title', this.title);
      formData.append('description', this.description);
      formData.append('price', this.price);
      formData.append('tags', JSON.stringify(this.tags));
      formData.append('userEmail', this.member.id);

      this.files.forEach((file) => {
        formData.append('images', file);
      });

      try {
        await axios.post('http://localhost:3000/products/register', formData, {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });
        alert('상품 등록 성공!');
      } catch (error) {
        console.error('상품 등록 실패:', error);
        alert('상품 등록 중 오류가 발생했습니다.');
      }
    },
  }
};
</script>

<style>
  /* 전체 페이지 레이아웃 */
.upload-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f7f7f7;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
  font-size: 2rem;
  margin-bottom: 1.5rem;
  color: #333;
}

/* 폼 레이아웃 */
.upload-form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* 인풋 그룹 */
.input-group {
  display: flex;
  flex-direction: column;
}

/* 라벨 스타일 */
.form-label {
  font-weight: bold;
  margin-bottom: 0.5rem;
  color: #555;
}

/* 인풋 스타일 */
.form-input {
  padding: 10px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #fff;
  transition: border-color 0.2s;
}

.form-input:focus {
  border-color: #007bff;
  outline: none;
}

.form-textarea {
  padding: 10px;
  font-size: 1rem;
  border: 1px solid #ddd;
  border-radius: 5px;
  background-color: #fff;
  height: 100px;
  resize: vertical;
  transition: border-color 0.2s;
}

.form-textarea:focus {
  border-color: #007bff;
  outline: none;
}

/* 태그 스타일 */
.tags-container {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.tag {
  display: inline-block;
  background-color: #007bff;
  color: #fff;
  padding: 5px 10px;
  border-radius: 20px;
  font-size: 0.9rem;
}

.remove-tag {
  background: none;
  border: none;
  color: #fff;
  font-weight: bold;
  margin-left: 10px;
  cursor: pointer;
}

.remove-tag:hover {
  color: #ddd;
}

/* 이미지 미리보기 스타일 */
.image-preview-container {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.preview-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 10px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* 버튼 스타일 */
.submit-btn {
  padding: 10px 15px;
  font-size: 1.1rem;
  background-color: #007bff;
  color: #fff;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.2s;
}

.submit-btn:hover {
  background-color: #0056b3;
}

/* 반응형 디자인 */
@media (max-width: 768px) {
  .upload-page {
    padding: 15px;
  }

  .form-label {
    font-size: 0.9rem;
  }

  .form-input, .form-textarea {
    font-size: 0.9rem;
  }

  .submit-btn {
    font-size: 1rem;
  }

  .preview-image {
    width: 80px;
    height: 80px;
  }
}
</style>
