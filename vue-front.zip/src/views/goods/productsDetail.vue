<template>
  <div class="container mt-5 product-detail-page">
    <!-- 상단 박스: 제목과 가격 -->
    <div class="card text-center mb-4">
      <div class="card-body ">
        <h1 class="card-title">{{ product.title }}</h1>
        <hr>
        <p class="card-text display-6 text-end">{{ product.price }}원</p>
      </div>
<!-- 구매 버튼 -->
<div class="mb-4 text-end"> <!-- text-end 클래스 사용 -->
        <button class="btn btn-success col-1 mx-2" @click="purchaseProduct">구매하기</button>
      </div>
        <!-- 태그들 표시 -->
        <div class="tags-container mt-3 justify-content-end  ">
          <span v-for="(tag, index) in product.tags" :key="index" class="badge bg-primary m-2">{{ tag }}</span>
        </div>
    </div>

<!-- 중간 박스: Bootstrap 이미지 캐러셀 -->
<div id="carouselExample" class="carousel slide mb-4" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div v-for="(image, index) in product.images" :key="index" :class="['carousel-item', { active: index === 0 }]">
      <img :src="getImageUrl(image)" alt="상품 이미지" class="d-block w-100 img-fluid product-image" />
    </div>
  </div>
  
  <!-- 좌우 이동 버튼 -->
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
    <span class="carousel-control-prev-icon custom-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>

  <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
    <span class="carousel-control-next-icon custom-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>


    <!-- 하단 박스: 상품 설명 -->
    <div class="card">
      <div class="card-body text-center">
        <h2>상품 설명</h2>
        <hr>
        <p class="card-text">{{ product.description }}</p>
      </div>
    </div>
  </div>
</template>

<script>

import axios from 'axios';

export default {

  data() {
    return {
      product: {
        title: '',
        price: 0,
        description: '',
        images: [], // 이미지 배열
        tags: [] // 태그 배열
      }
    };
  },
  created() {
    this.fetchProductDetails();
  },
  computed: {
  member() {
    return this.$store.state.member; // Vuex의 member 상태 직접 참조
  }
},
  methods: {
    async fetchProductDetails() {
      const productId = this.$route.params.id;
      try {
        const response = await axios.get(`http://localhost:3000/products/${productId}`);
        this.product = response.data;

        // 이미지가 쉼표로 구분된 문자열이라면 배열로 변환
        if (typeof this.product.images === 'string') {
          this.product.images = this.product.images.split(',');
        }
          // 태그가 쉼표로 구분된 문자열이라면 배열로 변환
          if (typeof this.product.tags === 'string') {
          this.product.tags = JSON.parse(this.product.tags); // JSON.parse로 변환
        }
      } catch (error) {
        console.error('상품 세부 정보를 가져오는 중 오류가 발생했습니다:', error.response ? error.response.data : error.message);
      }
    },
    getImageUrl(image) {
      return `http://localhost:3000/uploads/${image}`; // 이미지 경로 설정
    },
     // 구매하기 버튼 클릭 시 호출되는 메서드
     async purchaseProduct() {
      try {
        const response = await axios.post('http://localhost:3000/products/purchase', {
          productId: this.$route.params.id, // 제품 ID
          buyerId: this.member.id // 로그인된 회원의 ID
        });

        if (response.data.success) {
          alert('구매가 완료되었습니다!');
        } else {
          alert('구매에 실패했습니다: ' + response.data.message);
        }
      } catch (error) {
        console.error('구매 처리 중 오류가 발생했습니다:', error.response ? error.response.data : error.message);
        alert('구매 처리 중 오류가 발생했습니다.');
      }
    },
  }
};
</script>

<style scoped>
.product-detail-page {
  max-width: 1200px;
  margin: 0 auto;
}

/* 이미지가 비율을 유지하며 부모 컨테이너 안에 들어가도록 설정 */
.product-image {
  width: 100%;
  height: 400px;
  object-fit: contain; /* 이미지 비율을 유지하며, 부모 요소 안에 맞게 조정 */
  background-color: #f9f9f9; /* 이미지가 부족한 영역에 백그라운드 색상 추가 */
}
/* 좌우 이동 버튼의 아이콘 색상을 검은색으로 변경 */
.custom-prev-icon,
.custom-next-icon {
  background-color: black; /* 검은색으로 설정 */
  width: 30px; /* 아이콘 너비 */
  height: 30px; /* 아이콘 높이 */
  border-radius: 30%; /* 둥근 버튼으로 설정 */
}



</style>
