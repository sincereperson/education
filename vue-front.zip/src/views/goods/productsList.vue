<template>

  <div class="container">
    <!-- <pre>{{ member }}</pre> -->
    <div class="row">
      <div class="col-10"></div>
                    <div class="btn-group col-2 justify-content-end mt-1">
                  <button class="btn btn-primary mx-2" @click="goToAdd()">작품 등록</button>
                  <!-- <button
                    type="button"
                    class="btn btn-secondary dropdown-toggle"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                    id="dropdownMenuButton"
                  >
                    정렬하기
                  </button>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#">가나다순</a></li>
                    <li><a class="dropdown-item" href="#">가격순⭡</a></li>
                    <li><a class="dropdown-item" href="#">가격순⭣</a></li>
                    <li><a class="dropdown-item" href="#">인기순⭡</a></li>
                    <li><a class="dropdown-item" href="#">인기순⭣</a></li>
                  </ul>
                </div> -->
              </div>
  <div class="product-list-page">
    <h2>작품 목록</h2>

    <!-- 작품 목록 그리드 -->
    <div class="product-grid">
      <div class="product-card" v-for="(product, index) in products" :key="index">
        <img :src="getFirstImage(product.images)" alt="" class="product-image" />
        <!-- <img src="../../../../node-back/uploads/1728938462614.png" alt=""> -->
        <div class="product-info">
          <h3>{{ product.title }}</h3>
          <!-- <p>{{ product.description }}</p> -->
          <p class="product-price">{{ product.price }}원</p>
          <button @click="viewProduct(product.id)" class="view-btn">작품 보기</button>
        </div>
      </div>
    </div>
  </div>

    <!-- 페이지네이션 -->
    <div class="pagination">
      <button @click="goToPage(currentPage - 1)" :disabled="currentPage === 1">이전</button>
      <button v-for="page in totalPages" :key="page" @click="goToPage(page)" :class="{ active: currentPage === page }">
        {{ page }}
      </button>
      <button @click="goToPage(currentPage + 1)" :disabled="currentPage === totalPages">다음</button>
    </div>
  </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      products: [], // 서버에서 가져온 작품 목록
      currentPage: 1, // 현재 페이지
      itemsPerPage: 6, // 한 페이지에 표시할 작품 수
      totalPages: 1, // 전체 페이지 수
    };
  },
  created() {
    this.fetchProducts(); // 컴포넌트가 생성될 때 작품 목록을 가져옴

  },
  computed: {
  member() {
    return this.$store.state.member; // Vuex의 member 상태 직접 참조
  }
},
  methods: {
    async fetchProducts() {
      try {
        const response = await axios.get('http://localhost:3000/products/products', {
          params: {
            page: this.currentPage, // 현재 페이지를 쿼리 파라미터로 전송
            limit: this.itemsPerPage // 한 페이지에 표시할 상품 수
          }
        });

        this.products = response.data.products; // 서버에서 받은 작품 목록
        this.totalPages = response.data.totalPages; // 전체 페이지 수
      } catch (error) {
        console.error('작품 목록을 불러오는 중 오류가 발생했습니다:', error);
      }
    },
     getFirstImage(images) {
  if (images && images.length > 0) {
    // 서버의 uploads 폴더에서 첫 번째 이미지를 가져옴
    const imgUrl = `http://localhost:3000/uploads/${images.split(',')[0]}`;
    // console.log('이미지 경로:', imgUrl); // 이미지 경로를 콘솔에 출력하여 확인
    return imgUrl;
  }
  return '/path/to/default-image.jpg'; // 이미지가 없을 때 기본 이미지 반환
}
,
    goToPage(page) {
      if (page > 0 && page <= this.totalPages) {
        this.currentPage = page;
        this.fetchProducts(); // 페이지 변경 시 작품 목록 다시 가져오기
      }
    },
    viewProduct(id) {
    this.$router.push({ path: `/productsDetail/${id}` }); // 작품 상세 페이지로 이동
  },

    goToAdd(){
       this.$router.push({path: '/goods_add_picture'});
    }
  }
};
</script>

<style>
  .product-list-page {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

h2 {
  text-align: center;
  margin-bottom: 40px;
  font-size: 2.5rem;
  color: #333;
}

.product-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
}

.product-card {
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  overflow: hidden;
  transition: transform 0.3s ease;
}

.product-card:hover {
  transform: scale(1.05);
}

.product-image {
  width: 100%;
  height: 200px; /* 원하는 높이로 설정 */
  object-fit: contain; /* 이미지 비율을 유지하면서 박스에 맞춤 */
  border-radius: 10px; /* 카드 모서리의 둥근 효과와 맞추기 */
}

.product-info {
  padding: 20px;
  text-align: center;
}

.product-info h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.product-info p {
  font-size: 1rem;
  color: #666;
}

.product-price {
  font-size: 1.2rem;
  color: #007bff;
  margin-top: 10px;
}

.view-btn {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 10px 20px;
  margin-top: 20px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.view-btn:hover {
  background-color: #0056b3;
}

/* 페이지네이션 스타일 */
.pagination {
  display: flex;
  justify-content: center;
  margin-top: 30px;
}

.pagination button {
  background-color: #007bff;
  color: white;
  border: none;
  padding: 10px 15px;
  margin: 0 5px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.pagination button.active {
  background-color: #0056b3;
}

.pagination button:hover:not(.active) {
  background-color: #0056b3;
}

.pagination button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}

</style>
