<template>
  <div class="main-page">


    <!-- 슬라이더 섹션 -->
    <section class="hero-slider mt-5">
      <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
          <!-- 이미지 슬라이드 -->
          <div
            v-for="(image, index) in sliderImages"
            :key="index"
            :class="['carousel-item', { active: index === 0 }]"
          >
            <img :src="image" class="d-block w-100" alt="슬라이드 이미지" />
          </div>
        </div>
        
        <!-- 이전 버튼 -->
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        
        <!-- 다음 버튼 -->
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </section>

    <!-- 뉴스 섹션 -->
    <section class="news-section container">
      <h2 class="section-title">Art News</h2>
      <div class="news-grid">
        <div v-for="(news, index) in newsList" :key="index" class="news-card">
          <img :src="news.image" alt="news image" class="news-image" />
          <div class="news-content">
            <h3>{{ news.title }}</h3>
            <p>{{ news.description }}</p>
            <!-- <a href="https://www.kmisul.com/news/articleView.html?idxno=3954" class="read-more">Read More</a> -->
          </div>
        </div>
      </div>
    </section>
    
    <div class="room-selection">
      <label for="room">채팅방 선택</label>
      <select v-model="roomId" @change="joinRoom">
        <option v-for="room in rooms" :key="room.id" :value="room.id">{{ room.name }}</option>
      </select>
    </div>
    
    <div class="messages">
      <div
      v-for="(msg, index) in messages"
      :key="index"
      :class="['message', msg.senderId === userId ? 'sent' : 'received']"
      >
      <strong v-if="msg.senderId !== userId">{{ msg.senderId }}:</strong>
      {{ msg.message }}
    </div>
  </div>
  
  <input v-model="newMessage" placeholder="메시지 입력" @keydown.enter="sendMessage" />
  <button @click="sendMessage">전송</button>
</div>
</template>

<script>
import { io } from "socket.io-client";
export default {
  data() {
    return {
      sliderImages: [
        'https://www.art1.com/upload/banner/1719381986SS9AWA9SGW.jpg',
        'https://www.art1.com/upload/banner/1719381967VNK5W5VQZ9.jpg',
        'https://www.art1.com/upload/banner/171938190325WAG8VB2D.jpg',
      ],
      newsList: [
        { title: '제네시스-뉴욕메트로 폴리탄 파트너쉽', description: '첫 번째 전시 개막', image: 'https://cdn.kmisul.com/news/photo/202409/3954_11345_1726208684.jpeg',},
        { title: '프리즈 서울 2024 성료,학고재 갤러리 리뷰', description: '김환기, 백남준, 변월룡 등 한국 근현대 미술사에 영향력 있는 작가 8인 작품 선보여..', image: 'https://cdn.kmisul.com/news/photo/202409/3949_11329_230.jpg' },
        { title: '패션계 전설 르네 그뤼오 전시', description: '르 엘레강스 개최', image: 'https://cdn.kmisul.com/news/photo/202410/4026_11492_1728260847.jpg' },
      ],
      socket: null,
    roomId: "general", // 기본 방 설정
    newMessage: "",
    messages: [], // 모든 메시지
    rooms: [
      { id: "general", name: "일반 채팅방" },
      { id: "art", name: "미술 채팅방" },
      { id: "music", name: "음악 채팅방" },
      { id: "book", name: "책 채팅방" }
    ],
    };
  },
  props: {
  userId: { type: Number, required: true } // 유저 ID 전달
},
created() {
  this.socket = io("http://localhost:3000", { withCredentials: true });

  // 기본 방 입장
  this.joinRoom();

  // 서버에서 메시지 수신
  this.socket.on('message', (message) => {
    this.messages.push(message);
  });
},
methods: {
  // 방 입장
  joinRoom() {
    this.socket.emit('joinRoom', { roomId: this.roomId });
    this.messages = [];
  },
  // 메시지 전송
  sendMessage() {
    if (this.newMessage.trim() !== "") {
      this.socket.emit('chatMessage', {
        roomId: this.roomId,
        message: this.newMessage,
        senderId: this.userId
      });
      this.newMessage = "";
    }
  }
},
beforeUnmount() {
  this.socket.disconnect();
}
};

</script>

<style scoped>
/* 기본 레이아웃 및 스타일 */
body {
  margin: 0;
  font-family: 'Arial', sans-serif;
}

.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 20px;
}

.logo {
  font-size: 24px;
  font-weight: bold;
}

.nav-links {
  list-style: none;
  display: flex;
  gap: 15px;
}

.nav-links li a {
  color: white;
  text-decoration: none;
}

.nav-links li a:hover {
  text-decoration: underline;
}

/* 슬라이더 섹션 */
.hero-slider {
  position: relative;
  height: 600px;
  overflow: hidden;
}

.slide {
  height: 100%;
  background-size: cover;
  background-position: center;
  display: flex;
  justify-content: center;
  align-items: center;
}

.slide-text {
  color: white;
  text-align: center;
}

.slide h1 {
  font-size: 48px;
}

.slide p {
  font-size: 24px;
}

/* 뉴스 섹션 */
.news-section {
  padding: 40px 0;
}

.section-title {
  font-size: 32px;
  text-align: center;
  margin-bottom: 20px;
}

.news-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 20px;
}

.news-card {
  background-color: white;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  overflow: hidden;
  text-align: center;
}

.news-image {
  width: 100%;
  height: 200px;
  object-fit: cover;
}

.news-content {
  padding: 20px;
}

.news-content h3 {
  font-size: 20px;
  margin-bottom: 10px;
}

.read-more {
  color: #007bff;
  text-decoration: none;
}

.read-more:hover {
  text-decoration: underline;
}

.chat-container {
width: 50%;
max-width: 600px;
margin: 0 auto;
}

.messages {
height: 300px;
overflow-y: auto;
border: 1px solid #ccc;
margin-bottom: 10px;
padding: 10px;
}

.message {
display: flex;
padding: 10px;
margin-bottom: 10px;
max-width: 5%;
}

.sent {
justify-content: flex-end; /* 오른쪽 정렬 */
background-color: #d1e7dd; /* 본인 메시지 배경색 */
align-self: flex-end;
border-radius: 10px 0 10px 10px;
}

.received {
justify-content: flex-start; /* 왼쪽 정렬 */
background-color: #f8f9fa; /* 상대방 메시지 배경색 */
align-self: flex-start;
border-radius: 0 10px 10px 10px;
}

input {
width: 200px;
padding: 10px;
margin-right: 10px;
}

button {
padding: 10px;
}

.room-selection {
margin-bottom: 10px;
}
</style>
