<template>
  <div class="mypage-container">
    <header class="page-header">
      <h1>마이페이지</h1>
    </header>

    <!-- 메인 컨텐츠 -->
    <div class="row">
      <div class="col-md-3">
        <div class="nav flex-column nav-pills" aria-orientation="vertical">
          <a class="nav-link" :class="{ active: currentTab === 'profile' }" @click="currentTab = 'profile'">
            프로필 관리
          </a>
          <a class="nav-link" :class="{ active: currentTab === 'assets' }" @click="currentTab = 'assets'">
            자산 관리
          </a>
          <a class="nav-link" :class="{ active: currentTab === 'inquiry' }" @click="currentTab = 'inquiry'">
            1대1 문의
          </a>
        </div>
      </div>

      <!-- 우측 페이지 내용 -->
      <div class="col-md-9 tab-content-container">
        <div v-if="currentTab === 'profile'" class="tab-content">
          <h3>프로필 관리</h3>
          <div>
            <p><strong>이름:</strong> {{ userProfile.username }}</p>
            <p><strong>이메일:</strong> {{ userProfile.email }}</p>
            <p><strong>유형:</strong> {{ userProfile.type }}</p>
            <p><strong>잔액:</strong> {{ userProfile.balance }} point</p>
          </div>

          <!-- 이미지 및 자기소개 변경 -->
          <div class="profile-edit mt-2">
            <div class="form-group">
              <label for="selfIntro"><strong>자기소개</strong></label>
              <textarea v-model="selfIntro" class="form-control" id="selfIntro" placeholder="자기소개를 입력하세요"></textarea>
            </div>

            <div class="form-group mt-2">
              <label for="profileImage">프로필 이미지</label>
              <br>
              <input type="file" @change="onImageChange" class="form-control-file" id="profileImage" />
              <img v-if="imagePreview" :src="imagePreview" class="img-fluid mt-2" alt="이미지 미리보기" />
            </div>

            <button class="btn btn-primary mt-3" @click="updateProfile">프로필 업데이트</button>
        </div>
      </div>

       <!-- 자산 관리 탭 -->
       <div v-else-if="currentTab === 'assets'" class="tab-content">
          <h3>자산 관리</h3>

            <!-- 메인 컨텐츠 -->
    <div class="asset-management-container">
      
      <!-- 내 지갑 섹션 -->
      <section class="asset-section wallet-section mb-4">
        <h3>내 지갑</h3>
        <div class="wallet-info">
          <p><strong>현재 잔액:</strong> {{ userProfile.balance }} 크레딧</p>
          <button class="btn btn-primary mb-2" v-on:click="pay('카드')">크레딧 충전</button>
        </div>
        <h4>충전 내역</h4>
        <ul>
          <li v-for="(transaction, index) in creditTransactions" :key="index">
            {{ transaction.amount }} 크레딧 - {{ transaction.created_at }}
          </li>
        </ul>
      </section>

 
          <!-- 구매 내역 -->
          <section class="asset-section mt-4">
            <h3>구매 내역</h3>
      <ul v-if="purchases.length">
        <li v-for="purchase in purchases" :key="purchase.id">
          {{ purchase.title }} - {{ purchase.price }} 크레딧 - {{ purchase.created_at }}
        </li>
      </ul>
      <p v-else>구매 내역이 없습니다.</p>
          </section>

          <!-- 판매 내역 -->
          <section class="asset-section mt-4">
            <h3>판매 내역</h3>
      <ul v-if="sales.length">
        <li v-for="sale in sales" :key="sale.id">
          {{ sale.title }} - {{ sale.price }} 크레딧 - {{ sale.created_at }}
        </li>
      </ul>
      <p v-else>판매 내역이 없습니다.</p>
            
          </section>

          <!-- 환급 신청 -->
          <section class="asset-section mt-4">
            <h4>환급 신청</h4>
            <p><strong>환급 가능 금액:</strong> {{ userProfile.balance }} 크레딧</p>
            <button class="btn btn-success" @click="requestWithdrawal">환급 신청</button>
            <ul>
              <li v-for="(withdrawal, index) in withdrawalRequests" :key="index">
                {{ withdrawal.amount }} 크레딧 - 상태: {{ withdrawal.status }}
              </li>
            </ul>
           
          </section>
    </div>
  </div>

        <!-- 1대1문의 -->
        <div v-else-if="currentTab === 'inquiry'" class="tab-content">
          <h3>1대1 문의</h3>
          <div>
            <ul>
              <li v-for="(inquiry, index) in inquiries" :key="index">
                <p><strong>제목:</strong> {{ inquiry.title }}</p>
                <p><strong>상태:</strong> {{ inquiry.status }}</p>
              </li>
            </ul>
            <div v-if="inquiries.length === 0">
              <p>문의 내역이 없습니다.</p>
            </div>
            <div v-if="showModal" class="modal-backdrop">
        <div class="modal-content">
          <h3>문의하기</h3>

          <div class="form-group">
            <label for="title">제목</label>
            <input type="text" v-model="newInquiry.title" id="title" class="form-control" />
          </div>

          <div class="form-group">
            <label for="content">내용</label>
            <textarea v-model="newInquiry.content" id="content" class="form-control"></textarea>
          </div>

          <div class="modal-buttons">
            <button class="btn btn-success" @click="submitInquiry">제출하기</button>
            <button class="btn btn-secondary" @click="showModal = false">취소</button>
          </div>
        </div>
      </div>
        </div>
        <!-- 문의하기 버튼 -->
        <button class="btn btn-primary" @click="showModal = true">문의하기</button>
        </div>
        
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import { loadTossPayments } from "@tosspayments/payment-sdk";
const clientKey = "test_ck_D5GePWvyJnrK0W0k6q8gLzN97Eoq";

let func1 = loadTossPayments(clientKey);

export default {
  data() {
    return {
      currentTab: 'profile', // 기본 탭
      userProfile: {}, // 유저 프로필 정보
      selfIntro: '', // 자기소개
      profileImage: null, // 업로드할 프로필 이미지 파일
      imagePreview: null, // 이미지 미리보기
      inquiries: [], // 1대1 문의 목록
      showModal: false, // 모달 창 상태 (팝업 열기/닫기)
      newInquiry: {
        title: '',
        content: ''
      }
    };
  },
  computed: {
    member() {
      return this.$store.state.member; // Vuex에서 로그인된 유저 정보 가져오기
    }
  },
  created() {
    this.fetchUserProfile();
    this.fetchInquiries();
    this.fetchPurchases();
    this.fetchSales();
  },
  methods: {
    pay: function (method) {
      func1.then((tossPayments) => {
        let amt = 50000;
        let orderId = new Date().getTime();

        tossPayments
          .requestPayment(method, {
            amount: amt,
            orderId: orderId,
            orderName: "크레딧충전",
            customerName: "",
            successUrl: "http://localhost:8080/success",
            failUrl: "http://localhost:8080/fail",
          })
          .catch((error) => {
            if (error.code === "USER_CANCEL") {
              alert("유저가 취소했습니다.");
            } else {
              alert(error.message);
            }
          });
      });
    },
    async fetchUserProfile() {
      try {
        const response = await axios.get(`http://localhost:3000/mypage/profile/${this.member.id}`);
        this.userProfile = response.data;
        this.selfIntro = this.userProfile.self_intro; // 자기소개 초기 설정
        this.imagePreview = `http://localhost:3000/uploads/${this.userProfile.profile_image}`; // 프로필 이미지 미리보기
      } catch (error) {
        console.error('프로필 정보를 가져오는 중 오류가 발생했습니다:', error);
      }
    },
    onImageChange(event) {
      const file = event.target.files[0];
      this.profileImage = file;
      this.imagePreview = URL.createObjectURL(file); // 이미지 미리보기
    },
    async updateProfile() {
      const formData = new FormData();
      formData.append('self_intro', this.selfIntro);

      if (this.profileImage) {
        formData.append('profile_image', this.profileImage);
      }

      try {
        await axios.post(`http://localhost:3000/mypage/update-profile/${this.member.id}`, formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });
        alert('프로필이 성공적으로 업데이트되었습니다!');
        this.fetchUserProfile(); // 업데이트 후 프로필 정보 새로고침
      } catch (error) {
        console.error('프로필 업데이트 중 오류가 발생했습니다:', error);
        alert('프로필 업데이트 중 오류가 발생했습니다.');
      }
    },
    //문의내역 가져오기
    async fetchInquiries() {
      try {
        const response = await axios.get(`http://localhost:3000/mypage/inquiries/${this.member.id}`);
        this.inquiries = response.data;
      } catch (error) {
        console.error('1대1 문의 목록을 가져오는 중 오류가 발생했습니다:', error);
      }
    },
    // 문의하기 제출
    async submitInquiry() {
      try {
        const response = await axios.post(`http://localhost:3000/mypage/inquiries/create`, {
          user_id: this.member.id,
          title: this.newInquiry.title,
          content: this.newInquiry.content
        });

        if (response.data.success) {
          alert('문의가 성공적으로 등록되었습니다.');
          this.showModal = false; // 모달 닫기
          this.newInquiry.title = ''; // 폼 초기화
          this.newInquiry.content = '';
          this.fetchInquiries(); // 문의 내역 갱신
        }
      } catch (error) {
        console.error('문의 등록 중 오류가 발생했습니다:', error);
      }
    },
    async fetchPurchases() {
      try {
        const response = await axios.get(`http://localhost:3000/mypage/purchases/${this.member.id}`);
        this.purchases = response.data;
      } catch (error) {
        console.error('구매 내역을 가져오는 중 오류가 발생했습니다:', error);
      }
    },
    async fetchSales() {
      try {
        const response = await axios.get(`http://localhost:3000/mypage/sales/${this.member.id}`);
        this.sales = response.data;
      } catch (error) {
        console.error('판매 내역을 가져오는 중 오류가 발생했습니다:', error);
      }
    },
async requestWithdrawal() {

  alert('미구현기능입니다.');
},
    },
  }
</script>

<style scoped>
.mypage-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  background-color: #f8f9fa;
}

.page-header {
  width: 100%;
  background-color: #007bff;
  color: white;
  text-align: center;
  padding: 20px;
  margin-bottom: 20px;
}

.nav-link {
  cursor: pointer;
}

.nav-link.active {
  background-color: #007bff;
  color: white;
}

.tab-content-container {
  background-color: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}
.modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}

.modal-content {
  background-color: white;
  padding: 20px;
  border-radius: 5px;
  max-width: 500px;
  width: 100%;
}

.modal-buttons {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
}
/* 자산 관리 전체 컨테이너 */
.asset-management-container {
  background-color: white;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* 자산 관리 각 섹션 */
.asset-section {
  margin-bottom: 40px;
}

/* 내 지갑, 구매 내역, 판매 내역, 환급 신청 */
.wallet-section, .purchase-section, .sale-section, .withdrawal-section {
  border: 1px solid #ddd;
  padding: 15px;
  border-radius: 5px;
  background-color: #f8f9fa;
}

/* 섹션 헤더 */
h3 {
  border-bottom: 1px solid #ddd;
  padding-bottom: 10px;
  margin-bottom: 15px;
}

/* 리스트 스타일 */
ul {
  list-style: none;
  padding: 0;
}

li {
  padding: 10px;
  border-bottom: 1px solid #ddd;
}

li:last-child {
  border-bottom: none;
}

.btn-primary, .btn-success {
  margin-top: 10px;
}
</style>
